 $(document).ready(function() {

    $('select').multiselect({ numberDisplayed: 100, buttonContainer: '<div class="multiselect btn-group" />'});

    
 });