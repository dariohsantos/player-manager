As of PDK 5.1 the User's Guide has been migrated into the Technical Resource Center and is no longer available in PDF format. 

To view the guide, log in to the TRC and visit http://help.theplatform.com/display/pdk/PDK+user%27s+guide

The complete documentation set for the PDK is available on the TRC at http://help.theplatform.com/display/pdk.
