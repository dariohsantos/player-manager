<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CI_Ftp_service {

	var $ci;
	var $akamaiServer;
	var $akamaiUser;
	var $akamaiPass;
	var $configFileLocation;

	public function __construct(){		
		$this->ci = & get_instance();
		$this->ci->load->config('ftp');
		$this->ci->load->helper('url');
		$this->ci->load->model('upload_progress_model');	

		$this->akamaiServer = $this->ci->config->item('akamai_server');
		$this->akamaiUser = $this->ci->config->item('akamai_user');
		$this->akamaiPass = $this->ci->config->item('akamai_pass');
		$this->akamaiBaseDir = $this->ci->config->item('akamai_base_dir');
		$this->configFileLocation = $this->ci->config->item('config_file_location');
	}

	function prepareUpload($player){
		$this->ci->load->model('upload_progress_model');	
		$this->ci->upload_progress_model->prepareUpload($player['id']);	
	}

	function createOrUpdate($player){
					

		$playerDir = $this->akamaiBaseDir . "/" . url_title($player['name']);

		$conn_id = ftp_connect($this->akamaiServer); 
		
		ftp_login($conn_id, $this->akamaiUser, $this->akamaiPass );
		ftp_pasv($conn_id, true);
		
		if (!@ftp_chdir($conn_id, $playerDir)) {
			$this->create($player, $conn_id);
		} else {
			$this->update($player, $conn_id);
		}
		ftp_close($conn_id);				
	}



	function create($player, $conn_id){
		$srcDir =  $this->getSourcePath($player);
		$dstDir = $this->getDestPath($player);	
		$fileCount = $this->getFileCount($srcDir);
		$this->ci->upload_progress_model->initUpload($player['id'], $fileCount);	
		$this->uploadRecursive($conn_id, $player, $srcDir, $dstDir);		
		$this->ci->upload_progress_model->finalizeUpload($player['id']);
	}

	function update($player, $conn_id){
		$srcFile =  $this->getConfigFileSoure($player);
		$dstFile = $this->getConfigFileDest($player);
		$this->ci->upload_progress_model->initUpload($player['id'], 1);
		ftp_put($conn_id, $dstFile, $srcFile, FTP_ASCII);
		$this->ci->upload_progress_model->incrementCounter($player['id']);	
		$this->ci->upload_progress_model->finalizeUpload($player['id']);
	}

	function getSourcePath($player){
		$folderName = url_title($player['name']);
		return  FCPATH . "players" . '/' . $folderName;
	}

	function getDestPath($player){
		$folderName = url_title($player['name']);
		return $this->akamaiBaseDir . "/" . $folderName;
	}

	function getConfigFileSoure($player){
		return $this->getSourcePath($player) . "/" . $this->configFileLocation;
	}

	function getConfigFileDest($player){
		return $this->getDestPath($player) . "/" . $this->configFileLocation;
	}

	function uploadRecursive($conn_id, $player, $src_dir, $dst_dir) {		
	    $d = dir($src_dir);
	    ftp_mkdir($conn_id, $dst_dir);
	    while($file = $d->read()) { 
	        if ($file != "." && $file != "..") { 
	            if (is_dir($src_dir."/".$file)) { 
	                if (!@ftp_chdir($conn_id, $dst_dir."/".$file)) {
	                    ftp_mkdir($conn_id, $dst_dir."/".$file); 
	                }
	                $this->uploadRecursive($conn_id, $player, $src_dir."/".$file, $dst_dir."/".$file);
	            } else {
	                $upload = ftp_put($conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY);
	                $this->ci->upload_progress_model->incrementCounter($player['id']);	
	            }
	        }
	    }	  
	    $d->close();	    	    
	}

	function getFileCount($path){
	    $size = 0;
	    $ignore = array('.','..','cgi-bin','.DS_Store');
	    $files = scandir($path);

	    foreach($files as $t) {
	        if(in_array($t, $ignore)) continue;
	        if (is_dir(rtrim($path, '/') . '/' . $t)) {
	            $size += $this->getFileCount(rtrim($path, '/') . '/' . $t);
	        } else {
	            $size++;
	        }   
	    }
    	return $size;
	}

}