<?php
class Player extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in')){
			redirect('login', 'refresh');
		}
		$this->load->model('player_model');
		$this->load->model('view_mode_model');
		$this->load->helper('custom_url_helper');
	}

	public function index(){
		$data['players'] = $this->player_model->getAll();		
		$data['view'] = 'player/index';
		$data['title'] = 'players';
		$this->load->view('templates/layout', $data);		
	}

	public function edit($id){		
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['player'] = $this->player_model->get($id);
		$data['viewModes'] = $this->view_mode_model->getAll();
		$data['view'] = 'player/edit';				
		$this->load->view('templates/layout', $data);		
	}

	public function create(){		
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$data['viewModes'] = $this->view_mode_model->getAll();
		$data['view'] = 'player/save';				
		$this->load->view('templates/layout', $data);		
	}

	public function save(){		
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$this->load->library('file_service');

		$data['viewModes'] = $this->view_mode_model->getAll();

		$this->setValidations();		

		if ($this->form_validation->run() === FALSE){
			$data['error'] = TRUE;
			$data['player'] = $_POST;
			$data['view'] = 'player/save';		
		}else{
			$playerId = $this->player_model->setPlayer();
			$this->file_service->createOrUpdate($this->player_model->get($playerId));
			redirect('/player');		
		}
		$this->load->view('templates/layout', $data);		
	}

	public function delete($id){		
		$this->load->library('file_service');
		$this->file_service->delete($this->player_model->get($id));
		$this->player_model->delete($id);
		redirect('/player');		
	}

	public function upload($id){
		$this->load->library('ftp_service');
		$this->ftp_service->createOrUpdate($this->player_model->get($id));		
		redirect('/player');		
	}

	public function upload_state($id){
		$player = $this->player_model->get($id);		
		if($player['upload_state'] == INIT || $player['uploaded_files'] == 0){
			$result['state'] = 0;
		} else {
			$perc = $player['uploaded_files'] / $player['total_files'] * 100;
			$result['state'] = number_format ($perc, 2);		
		}
		header('Content-Type: application/json');
		echo json_encode($result);
	}

	public function init_upload($id){
 		$this->load->library('ftp_service');
		$this->ftp_service->prepareUpload($this->player_model->get($id));		
		$result['state'] = "OK";		
		header('Content-Type: application/json');
		echo json_encode($result);
	}

	public function iframe_code($id){				
 		$player = $this->player_model->get($id);
 		$iframeTemplate = '<iframe src=":url" frameBorder="0" width=":widthpx" height=":heightpx" scrolling="no" AllowFullScreen="true"/>';
 		$url = akamai_player_url($player['name']);
 		$result = str_replace(':url', $url, $iframeTemplate);
 		$result = str_replace(':width', $player['width'], $result);
 		$result = str_replace(':height',  $player['height'], $result);
 		$result = '<code>' . htmlentities($result) . '</code>';
		echo $result;
	}

	public function setValidations(){
		$this->form_validation->set_rules('name', 'nombre', 'required');		
		$this->form_validation->set_rules('width', 'ancho', 'required|integer');				
		$this->form_validation->set_rules('height', 'alto', 'required|integer');		
		$this->form_validation->set_rules('initial_view_mode', 'vista inicial', 'required');		
		$this->form_validation->set_rules('available_view_modes', 'vistas disponibles', 'required');
		$this->form_validation->set_rules('feeds', 'feeds', 'required');
	}
}