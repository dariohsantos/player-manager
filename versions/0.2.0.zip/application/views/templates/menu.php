<nav class="navbar navbar-default" role="navigation">   
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		<div class="container">
			<ul class="nav navbar-nav">
				<li><a href="<?=base_url('player')?>">players</a></li>				
				<li><a href="<?=base_url('user')?>">usuarios</a></li>
			</ul> 
			<ul class="nav navbar-nav navbar-right">
		        <li><a href="<?=base_url('login/logout')?>">logout</a></li>		    
	      	</ul>
		</div>
	</div>
</nav>