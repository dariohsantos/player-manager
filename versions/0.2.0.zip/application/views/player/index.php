<div class="panel panel-default row">
	<div class="panel-heading">
		<h2>Listado de players</h2>
	</div>		
	<div class="panel-body">
		<a href="<?=site_url('player/create')?>" class="btn btn-primary pull-right"><span class="glyphicon glyphicon-plus"></span> agregar</a>
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Nombre</th>
					<th>Ancho</th>
					<th>Alto</th>
					<th>Ultima modificaci&oacute;n</th>
					<th>Estado Akamai</th>
					<th></th>
				</tr>	
			</thead>
			<?php foreach ($players as $player_item): ?>
				<tr>
					<td><?=$player_item['name']?></td>
					<td><?=$player_item['width']?></td>
					<td><?=$player_item['height']?></td>
					<td><?=$player_item['update_date']?></td>	
					<td class="current_state">
						<?if($player_item['upload_state'] == FINISHED){ ?>
							<span class="label label-success">subido</span>
						<? } else if($player_item['upload_state'] == UPLOADING || $player_item['upload_state'] == INIT){ ?>
							<span class="label label-default uploading"></span>
						<? } else if($player_item['upload_state'] == MODIFIED){ ?>
							<span class="label label-danger">modificado</span>
						<? } else { ?>							
							<span class="label label-warning">pendiente</span>
						<? } ?>
					</td>					
					<td class="text-right">
						<a href="<?=site_url("player/edit/" . $player_item['id'])?>" class="action-button" data-toggle="tooltip" data-placement="top" title="" data-original-title="editar">
							<span class="glyphicon glyphicon-pencil green"></span>
						</a>
						<a href="<?=site_url("player/delete/" . $player_item['id'])?>" class="action-button" data-toggle="tooltip" data-placement="top" title="" data-original-title="eliminar"><span class="glyphicon glyphicon-trash red"></span></a>
						<a href="<?=site_url("player/upload/" . $player_item['id'])?>" class="action-button upload" data-toggle="tooltip" data-placement="top" title="" data-original-title="subir a akamai"><span class="glyphicon glyphicon-arrow-up orange"></span></a>
						<a href="<?=site_url("player/upload_state/" . $player_item['id'])?>" class="action-button upload_state hidden" ></a>
						<a href="<?=site_url("player/init_upload/" . $player_item['id'])?>" class="action-button init_upload hidden" ></a>
						<a href="<?=local_player_url($player_item['name'])?>" data-fancybox-type="iframe" class="action-button fancybox" data-toggle="tooltip" data-placement="top" title="" data-original-title="previsualizar"><span class="glyphicon glyphicon-eye-open black"></span></a>
						<a href="<?=akamai_player_url($player_item['name'])?>" data-fancybox-type="iframe" class="action-button fancybox" data-toggle="tooltip" data-placement="top" title="" data-original-title="ver en akamai"><span class="glyphicon glyphicon-paperclip black"></span></a>

						<a href="<?=site_url("player/iframe_code/" . $player_item['id'])?>" data-fancybox-type="iframe" class="action-button fancybox" data-toggle="tooltip" data-placement="top" title="" data-original-title="codigo iframe"><span class="glyphicon glyphicon glyphicon-chevron-left black"></span><span class="glyphicon glyphicon glyphicon-chevron-right black"></span></a>
					</td>
				</tr>
			<?php endforeach ?>
		</table>
	</div>
</div>
<script>
$(function () { 
    $("[data-toggle='tooltip']").tooltip(); 
});
$(document).ready(function() {
	$(".fancybox").fancybox({		
		fitToView	: true,
		autoSize	: true,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});

	$(".upload").click(uploadToAkamai);
	$(".uploading").each(function(){ 
		checkUpload($(this));
	});

	function uploadToAkamai(e){
		e.preventDefault();
		var uploadUrl = $(this).attr("href");		
		

		var uploadedStateUrl = $(this).parents('tr').find('.upload_state').attr('href');
		var initUploadUrl = $(this).parents('tr').find('.init_upload').attr('href');
		var uploadedStateTd = $(this).parents('tr').find('td.current_state');		
		
		$.get(initUploadUrl, function(){
			$.get(uploadUrl);
			checkUploadStateInterval(uploadedStateUrl, uploadedStateTd);		
		});					
	}

	function checkUpload(element){
		var uploadedStateUrl = element.parents('tr').find('.upload_state').attr('href');
		var uploadedStateTd = element.parents('tr').find('td.current_state');	
		checkUploadStateInterval(uploadedStateUrl, uploadedStateTd);	
	}

	function  checkUploadStateInterval(uploadedStateUrl, uploadedStateTd){
		var uploadIntervalId = setInterval(function(){
			checkUploadState(uploadedStateUrl, uploadedStateTd, uploadIntervalId);
		}, 1000);
	}

	function checkUploadState(uploadedStateUrl, uploadedStateTd, uploadIntervalId){			
		$.get(
			uploadedStateUrl,
			function(data){
				var htmlState = '';
				if(data.state < 100){
					htmlState = progressBarTemplate(data.state);	    							
    			} else {
    				htmlState = uploadFinishedTemplate();	    			
    				clearInterval(uploadIntervalId);
    			}
    			uploadedStateTd.html(htmlState);
			}
		);
	}

	function progressBarTemplate(perc){
		var context = {progress: perc}
	    var source   = $("#progress-bar-template").html();
	    var template = Handlebars.compile(source);   
	    return template(context);
	}

	function uploadFinishedTemplate(){
	    var source   = $("#uploaded-finished-template").html();
	    var template = Handlebars.compile(source);   
	    return template();
	}
});
</script>

<script id="progress-bar-template" type="text/x-handlebars-template">
	<div class="progress progress-striped">
	  <div class="progress-bar progress-bar-success text-center" role="progressbar" aria-valuenow="{{progress}}" aria-valuemin="0" aria-valuemax="100" style="width: {{progress}}%">	
	  </div>
	</div>
</script>

<script id="uploaded-finished-template" type="text/x-handlebars-template">
	<span class="label label-success">subido</span>
</script>