<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['akamai_server'] = 'lsdlive.upload.akamai.com';
$config['akamai_base_dir'] = '/279877/player';
$config['akamai_user'] = 'lsdlive';
$config['akamai_pass'] = '20LSDlive14';
$config['akamai_base_url'] = 'http://latinstatic.edgesuite.net/player';
$config['config_file_location'] = 'js/classes/Config.js';

/* End of file ftp.php */
/* Location: ./application/config/ftp.php */