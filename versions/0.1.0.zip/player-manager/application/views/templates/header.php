<header class="row">
	<div class="row padding-base-vertical">
		<div class="container">
			<div class="pull-left" >
				<h1 class="gray-lighter">Player manager</h1>
			</div>
			<img src="<?= Assets::img('logo.png')?>" class="pull-right"/>
		</div>
	</div>
</header> 