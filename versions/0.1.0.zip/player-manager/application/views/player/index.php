<div class="panel panel-default row">
	<div class="panel-heading">
		<h2>Listado de players</h2>
	</div>		
	<div class="panel-body">
		<a href="<?=base_url('player/create')?>" class="btn btn-primary pull-right"><span class="glyphicon glyphicon-plus"></span> agregar</a>
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Nombre</th>
					<th>Ancho</th>
					<th>Alto</th>
					<th>Ultima modificaci&oacute;n</th>
					<th></th>
				</tr>	
			</thead>
			<?php foreach ($players as $player_item): ?>
				<tr>
					<td><?=$player_item['name']?></td>
					<td><?=$player_item['width']?></td>
					<td><?=$player_item['height']?></td>
					<td><?=$player_item['update_date']?></td>			
					<td class="text-right">
						<a href="<?=base_url("player/edit/" . $player_item['id'])?>" class="action-button" data-toggle="tooltip" data-placement="top" title="" data-original-title="editar">
							<span class="glyphicon glyphicon-pencil green"></span>
						</a>
						<a href="<?=base_url("player/delete/" . $player_item['id'])?>" class="action-button" data-toggle="tooltip" data-placement="top" title="" data-original-title="eliminar"><span class="glyphicon glyphicon-trash red"></span></a>
						<a href="<?=base_url("player/upload/" . $player_item['id'])?>" class="action-button" data-toggle="tooltip" data-placement="top" title="" data-original-title="subir a akamai"><span class="glyphicon glyphicon-arrow-up orange"></span></a>
						<a href="<?=local_player_url($player_item['name'])?>" data-fancybox-type="iframe" class="action-button fancybox" data-toggle="tooltip" data-placement="top" title="" data-original-title="previsualizar"><span class="glyphicon glyphicon-eye-open black"></span></a>

						<a href="<?=akamai_player_url($player_item['name'])?>" data-fancybox-type="iframe" class="action-button fancybox" data-toggle="tooltip" data-placement="top" title="" data-original-title="ver en akamai"><span class="glyphicon glyphicon-paperclip black"></span></a>
					</td>
				</tr>
			<?php endforeach ?>
		</table>
	</div>
</div>
<script>
$(function () { 
    $("[data-toggle='tooltip']").tooltip(); 
});
$(document).ready(function() {
	$(".fancybox").fancybox({		
		fitToView	: true,
		autoSize	: true,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
});
</script>