<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('akamai_player_url')){
	function akamai_player_url($name){

		$ci = & get_instance();
		$ci->load->config('ftp');
		$ci->load->helper('url');

		$folderName = url_title($name);
		return $ci->config->item('akamai_base_url') . "/" . $folderName . "/" . "player.html";
	}
}

if ( ! function_exists('local_player_url')){
	function local_player_url($name){

		$ci = & get_instance();
		$ci->load->helper('url');

		$folderName = url_title($name);
		return base_url("/players/" . $folderName . "/" . "player.html");
	}
}