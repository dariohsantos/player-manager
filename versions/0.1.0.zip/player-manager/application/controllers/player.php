<?php
class Player extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('logged_in')){
			redirect('login', 'refresh');
		}
		$this->load->model('player_model');
		$this->load->model('view_mode_model');
	}

	public function index(){
		$data['players'] = $this->player_model->getAll();		
		$data['view'] = 'player/index';
		$data['title'] = 'players';
		$this->load->view('templates/layout', $data);		
	}

	public function edit($id){		
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['player'] = $this->player_model->get($id);
		$data['viewModes'] = $this->view_mode_model->getAll();
		$data['view'] = 'player/edit';				
		$this->load->view('templates/layout', $data);		
	}

	public function create(){		
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$data['viewModes'] = $this->view_mode_model->getAll();
		$data['view'] = 'player/save';				
		$this->load->view('templates/layout', $data);		
	}

	public function save(){		
		$this->load->helper('form');
		$this->load->library('form_validation');		
		$this->load->library('file_service');

		$data['viewModes'] = $this->view_mode_model->getAll();

		$this->setValidations();		

		if ($this->form_validation->run() === FALSE){
			$data['error'] = TRUE;
			$data['player'] = $_POST;
			$data['view'] = 'player/save';		
		}else{
			$playerId = $this->player_model->setPlayer();
			$this->file_service->createOrUpdate($this->player_model->get($playerId));
			redirect('/player');		
		}
		$this->load->view('templates/layout', $data);		
	}

	public function delete($id){		
		$this->load->library('file_service');
		$this->file_service->delete($this->player_model->get($id));
		$this->player_model->delete($id);
		redirect('/player');		
	}

	public function upload($id){
		$this->load->library('ftp_service');
		$this->ftp_service->createOrUpdate($this->player_model->get($id));		
		redirect('/player');		
	}

	public function setValidations(){
		$this->form_validation->set_rules('name', 'nombre', 'required');		
		$this->form_validation->set_rules('width', 'ancho', 'required|integer');				
		$this->form_validation->set_rules('height', 'alto', 'required|integer');		
		$this->form_validation->set_rules('initial_view_mode', 'vista inicial', 'required');		
		$this->form_validation->set_rules('available_view_modes', 'vistas disponibles', 'required');
		$this->form_validation->set_rules('feeds', 'feeds', 'required');
	}
}