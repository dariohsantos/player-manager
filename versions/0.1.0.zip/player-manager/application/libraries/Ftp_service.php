<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CI_Ftp_service {

	var $ci;

	function createOrUpdate($player){
		$this->ci = & get_instance();
		$this->ci->load->config('ftp');
		$this->ci->load->helper('url');


		$akamaiServer = $this->ci->config->item('akamai_server');
		$akamaiUser = $this->ci->config->item('akamai_user');
		$akamaiPass = $this->ci->config->item('akamai_pass');
		$akamaiBaseDir = $this->ci->config->item('akamai_base_dir');
		$playerDir = $akamaiBaseDir . "/" . url_title($player['name']);

		$conn_id = ftp_connect($akamaiServer); 
		
		ftp_login($conn_id, $akamaiUser, $akamaiPass );
		
		if (!@ftp_chdir($conn_id, $playerDir)) {
			$this->create($player, $conn_id);
		} else {
			$this->update($player, $conn_id);
		}
		ftp_close($conn_id);				
	}

	function create($player, $conn_id){
		$srcDir =  $this->getSourcePath($player);
		$dstDir = $this->getDestPath($player);		
		$this->uploadRecursive($conn_id, $srcDir, $dstDir);
	}

	function update($player, $conn_id){
		$srcFile =  $this->getConfigFileSoure($player);
		$dstFile = $this->getConfigFileDest($player);
		ftp_put($conn_id, $dstFile, $srcFile, FTP_ASCII);
	}

	function getSourcePath($player){
		$folderName = url_title($player['name']);
		return  FCPATH . "players" . '/' . $folderName;
	}

	function getDestPath($player){
		$folderName = url_title($player['name']);
		return $this->ci->config->item('akamai_base_dir') . "/" . $folderName;
	}

	function getConfigFileSoure($player){
		return $this->getSourcePath($player) . "/" . $this->ci->config->item('config_file_location');
	}

	function getConfigFileDest($player){
		return $this->getDestPath($player) . "/" . $this->ci->config->item('config_file_location');
	}

	function uploadRecursive($conn_id, $src_dir, $dst_dir) {
	    $d = dir($src_dir);
	    ftp_mkdir($conn_id, $dst_dir);
	    while($file = $d->read()) { // do this for each file in the directory
	        if ($file != "." && $file != "..") { // to prevent an infinite loop
	            if (is_dir($src_dir."/".$file)) { // do the following if it is a directory
	                if (!@ftp_chdir($conn_id, $dst_dir."/".$file)) {
	                    ftp_mkdir($conn_id, $dst_dir."/".$file); // create directories that do not yet exist	                    
	                }
	                $this->uploadRecursive($conn_id, $src_dir."/".$file, $dst_dir."/".$file); // recursive part
	            } else {
	                $upload = ftp_put($conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY); // put the files
	            }
	        }
	    }	  
	    $d->close();
	}








}