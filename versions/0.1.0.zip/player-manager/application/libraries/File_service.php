<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CI_File_service {

	var	$playersFolder = 'players';
	var $basePlayerFolder = 'players/player-base';
	var $ci;

	function delete($player){
		$this->recursive_delete($this->getPlayerFolder($player));
	}

	function createOrUpdate($player){
		$this->ci = & get_instance();
		$this->ci->load->helper('path');
		$this->ci->load->helper('url');
		$this->ci->load->model('view_mode_model');
		$currentPlayerFolder = $this->getPlayerFolder($player);
		if(is_dir($currentPlayerFolder)){
			$this->update($player);
		}
		else{			
			$this->create($player);
		}		
	}

	function getPlayerFolder($player){
		return FCPATH . $this->playersFolder . '/' . url_title($player['name']);
	}

	function getBasePlayerFolder(){
		return FCPATH . $this->basePlayerFolder;
	}

	function create($player){
		$this->recurse_copy($this->getBasePlayerFolder(), $this->getPlayerFolder($player));
		$json = $this->updateConfigFile($player);
	}

	function update($player){
		$json = $this->updateConfigFile($player);
	}

	function updateConfigFile($player){
		$playerFolder = $this->getPlayerFolder($player);
		$configFilePath = $this->getPlayerFolder($player) . "/js/classes/Config.js";			
		$configFile = fopen($configFilePath, "w");

		$data = "config = " . $this->getJsonForConfig($player);

		fwrite($configFile, $data);
		fclose($configFile);		
	}

	function getJsonForConfig($player){
		$result = array();
		$result['initialViewMode'] = $this->getViewModeName($player['initial_view_mode']);
		foreach($player['available_view_modes'] as $viewMode){
			$result['availableViewModes'][] = $viewMode['name'];
		}
		$result['showRightController'] = $player['show_right_controller']?TRUE:FALSE;
		$result['size']['height'] = $player['height'];
		$result['size']['width'] = $player['width'];
		foreach($player['feeds'] as $feed){
			$result['feeds'][] = $this->getJsonFeedForConfig($feed);
 		}
		return json_encode($result);
	}

	function getJsonFeedForConfig($feed){
		$result['name'] = $feed['name'];
		$result['url'] = $feed['url'];
		$result['init'] = $feed['init']?TRUE:FALSE;
		return $result;
	}

	function getViewModeName($viewModeId){
		$viewMode = $this->ci->view_mode_model->get($viewModeId);
		return $viewMode['name'];
	}

	function recurse_copy($src,$dst) { 
	    $dir = opendir($src); 
	    mkdir($dst); 
	    while(false !== ( $file = readdir($dir)) ) { 
	        if (( $file != '.' ) && ( $file != '..' )) { 
	            if ( is_dir($src . '/' . $file) ) { 
	                $this->recurse_copy($src . '/' . $file,$dst . '/' . $file); 
	            } 
	            else { 
	                copy($src . '/' . $file,$dst . '/' . $file); 
	            } 
	        } 
	    } 
	    closedir($dir); 
	} 

	 function recursive_delete($str){
        if(is_file($str)){
            return @unlink($str);
        }
        elseif(is_dir($str)){
            $scan = glob(rtrim($str,'/').'/*');
            foreach($scan as $index=>$path){
                $this->recursive_delete($path);
            }
            return @rmdir($str);
        }
    }

}