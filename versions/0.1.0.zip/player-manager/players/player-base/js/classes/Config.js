config = 
{
	feeds :
		[
			{name: "Live", url: "http://feed.theplatform.com/f/H2PcKC/4fwE8ONjnu1_", init: false},
			{name: "VOD", url: "http://feed.theplatform.com/f/H2PcKC/V6D7iv1yRwak", init: false},	
			{name: "infobae", url: "http://feed.theplatform.com/f/H2PcKC/83A9u8l0qzsv", init: true}	
			
		],
	info : 
		[
			{name: "Line up", data: "aca va la data sobre el line up", init: false}
		],
	initialViewMode : "picture",
	availableViewModes: ["split4", "split2","full", "picture"],
	showRightController: true,
	size: {height: 500, width: 800}
	
}