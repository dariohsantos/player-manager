<?php

// Load the assets library when loading the spark
$autoload['config']    = array('assets', 'assets_cssmin', 'assets_cdn');
$autoload['helper']    = array('url', 'file', 'directory', 'string', 'html', 'assets');
$autoload['libraries'] = array('assets');
